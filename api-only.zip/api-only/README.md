# API only WordPress theme
A simple theme to use when you want your WordPress instance to function only as a REST API. All normal web access is disabled, and a simple informational message displayed. Administrative users can log in as normal to manage content.

## Installation
Just upload the .zip file and activate.
